import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Dashboard.css"; // Import your CSS styles

function Cards() {
 
  
  return (
    <div className="cards">
      {/* Sidebar Navigation */}
     

     
      <main className="content">
        
      </main>
    </div>
  );
}

export default Cards;
